
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
        <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/e1fb7b13f7.js" crossorigin="anonymous"></script>
</head>
<body>
<?php
        $link = new mysqli("localhost","root","root","velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        if(isset($_POST['user']))
        {    
        $a=$_POST['user'];
        $b=$_POST['password'];

		$sql="SELECT * FROM `admin` WHERE `user`='$a' AND `password`='$b' limit 1";
		
		$result = mysqli_query($link,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
	  $count = mysqli_num_rows($result);

        if($count == 1){
			echo "success" ;
            header("Location:report.php");

        }
        else{
			echo "Failed";
            header("Location:index.html");
        }
    }
    mysqli_close($link);
     ?>
	<div class="container">
		<div class="img">
			<img src="img/bg5.svg">
		</div>
		<div class="login-content">
			<form action="admin.php" method="post">
				<img src="img/avatar.png">
				<h2 class="title" style="font-size :35px;">ADMIN LOGIN</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-envelope"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Username</h5>
           		   		<input type="text" class="input" name="user">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Password</h5>
           		    	<input type="password" class="input" name="password">
            	   </div>
            	</div><br>
            	<button type="submit" value="submit" id="submit" class="btn" name="submit">LOGIN</button>
            </form>
        </div>
	</div>
	<script src="js/main.js"></script>
</body>
</html>