<?php

   $conn = mysqli_connect('localhost','root','root','fresher');
   
   
   $sql = 'SELECT name, parent, Gender FROM registration where name="kannan mohan"';

   $retval = mysqli_query(  $conn,$sql );
      
   while($row = mysqli_fetch_array($retval)) {
       if($row['name'] == "ganesh siva"){
      echo "EMP ID :{$row['name']}  <br> ".
         "EMP NAME : {$row['parent']} <br> ".
         "EMP SALARY : {$row['Gender']} <br> ".
         "--------------------------------<br>";
        }
        else{
            echo  "EMP SALARY : {$row['Gender']} <br> ".
            "EMP NAME : {$row['parent']} <br> ".
            "--------------------------------<br>";
        }
   }
   
   echo "Fetched data successfully\n";
   
   mysqli_close($conn);
?>