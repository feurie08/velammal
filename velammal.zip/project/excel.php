<?php  
      //export.php  
  
      $connect = mysqli_connect("localhost", "root", "root", "velammal");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=db.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('Reference Number','First Name','Last Name','Date Of Birth','Email Address','Contact Number','Alternate Number','Living With','Parent/Guardian Name','Parent/Guardian Occupation','Mother Tongue','10th %','Address','District','State','Pincode','First Preference','Second Preference','Gender','Type','12th Registration Number','12th School Name','Type','Velammal Group','Board Of Study','Medium','12th Group','12th Expected','Diploma','12th Mark ','Registration Number','College','Department in Diploma','Date of Joining','Medium Of Instruction','From Where Registered','State Board Maths','State Board Physics','State Board Chemistry','AP Maths A','AP Maths B','AP Physics','AP Practical Physics','AP Chemistry','AP Practical Chemistry','CBSE Maths','CBSE Physics','CBSE Chemistry','Cutoff'));  
      $query = "SELECT `fname`,`lname`,`dob`,`email`,`password`,`cpassword`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`fpre`,`spre`,`gender`,`ref`,`regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`expected`,`diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med`,`smat`,`sphy`,`sche`,`cmat`,`cphy`,`cche`,`amata`,`amatb`,`aphy`,`apphy`,`ache`,`apche`,`scutoff` FROM `vel`"; 
	  $result = mysqli_query($connect, $query, MYSQLI_USE_RESULT);
     while($row =mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);   
 ?>  