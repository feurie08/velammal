<html>
<body>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.jqueryui.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
function myFunction() {
  window.print();
}
</script>

<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<center>
<b><font color="red" size=5>REPORT OF ADMISSION ENQUIRY</font></b><br><br>
<?php

 $link = new mysqli("localhost","root","root","velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
	   
        $sql="SELECT count(`fname`) as total FROM `vel`";
           $result = $link->query("$sql");
           $row = mysqli_fetch_assoc($result);
           echo "<table border=\"1\" cellspacing=\"0\" >";
           echo " <tr><td> <b>TOTAL NO OF ENQUIRIES<b></td>"; 
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>";
           
        $sql= "SELECT count(`fname`)as total FROM `vel` WHERE `choice`='Regular'";
           $result = $link->query("$sql");
           $row = mysqli_fetch_assoc($result);
           echo "<tr><td><b>TOTAL NO OF REGULAR ENQUIRIES<b></td>"; 
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>";
           
        $sql= "SELECT count(`fname`)as total FROM `vel` WHERE `choice`='Lateral'";
           $result = $link->query("$sql");
           $row = mysqli_fetch_assoc($result);
           echo "<tr><td><b>TOTAL NO OF LATERAL ENQUIRIES<b></td>";
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>"; 
           
        $sql= "SELECT count(*)as total FROM `vel` WHERE `vel`='yes'";
           $result = $link->query("$sql");
           $row = mysqli_fetch_assoc($result);
           echo "<tr><td><b>TOTAL NO OF VELAMMAL STUDENT ENQUIRIES<b></td>";
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>";    
           
            
         $sql= "SELECT count(`fname`)as total FROM `vel` WHERE `state`='Tamil Nadu'";
           $result = $link->query("$sql"); 
           $row = mysqli_fetch_assoc($result);
           echo "<tr><td><b>TOTAL NO OF ENQUIRIES FROM TAMIL NADU REGION <b></td>";
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>"; 
           
           $sql= "SELECT count(`fname`)as total FROM `vel` WHERE `state`='Andhra Pradesh'";
           $result = $link->query("$sql");
           $row = mysqli_fetch_assoc($result);
           echo "<tr><td><b>TOTAL NO OF ENQUIRIES FROM ANDHRA PRADESH REGION <b></td>"; 
           echo "<td>&nbsp &nbsp &nbsp &nbsp &nbsp".$row['total']." &nbsp &nbsp &nbsp &nbsp &nbsp</td><tr>"; 
          echo "</table>";
          echo "<br>";
          
      
          
         $sql= "SELECT count(*)as total FROM `vel` WHERE fpre='IT'";
           $result = $link->query("$sql");
           $row1 = mysqli_fetch_assoc($result);  
         $sql= "SELECT count(*)as total FROM `vel` WHERE fpre='CSE'";
           $result = $link->query("$sql");
           $row2 = mysqli_fetch_assoc($result);    
         $sql= "SELECT count(*)as total FROM `vel` WHERE fpre='EEE'";
           $result = $link->query("$sql");
           $row3 = mysqli_fetch_assoc($result);  
         $sql= "SELECT count(*)as total FROM `vel` WHERE fpre='ECE'";
           $result = $link->query("$sql");
           $row4 = mysqli_fetch_assoc($result);  
         $sql= "SELECT count(*)as total FROM `vel` WHERE fpre='MECH'";
           $result = $link->query("$sql");
           $row5 = mysqli_fetch_assoc($result);  
           echo "<b>TOTAL NO OF STUDENT'S 1ST PREFFERENCE :<b>&nbsp &nbsp &nbsp";
           echo "<br>";
           echo "<table border=\"1\" cellspacing=\"0\" >";
           echo "<tr><td><b>IT</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>CSE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>EEE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>ECE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>MECH</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td></tr>"; 
           echo  "<tr><td>".$row1['total']."</td><td>".$row2['total']."</td><td>".$row3['total']."</td><td>".$row4['total']."</td><td>".$row5['total']."</td><tr>";         
           echo "</table>";
           echo "<br><br>";
           
           
           
           
         $sql= "SELECT count(*)as total FROM `vel` WHERE spre='IT'";
           $result = $link->query("$sql");
           $row6 = mysqli_fetch_assoc($result);       
         $sql= "SELECT count(*)as total FROM `vel` WHERE spre='CSE'";
           $result = $link->query("$sql");
           $row7 = mysqli_fetch_assoc($result);        
         $sql= "SELECT count(*)as total FROM `vel` WHERE spre='EEE'";
           $result = $link->query("$sql");
           $row8 = mysqli_fetch_assoc($result);      
         $sql= "SELECT count(*)as total FROM `vel` WHERE spre='ECE'";
           $result = $link->query("$sql");
           $row9 = mysqli_fetch_assoc($result); 
          $sql= "SELECT count(*)as total FROM `vel` WHERE spre='MECH'";
           $result = $link->query("$sql");
           $row10 = mysqli_fetch_assoc($result);          
           echo "<b>TOTAL NO OF STUDENT'S 2nd PREFFERENCE :<b>&nbsp &nbsp &nbsp";
           echo "<br>";
           echo "<table border=\"1\" cellspacing=\"0\" >";
           echo "<tr><td><b>IT</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>CSE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>EEE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>ECE</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td>";
           echo"<td><b>MECH</b>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp</td></tr>"; 
           echo  "<tr><td>".$row6['total']."</td><td>".$row7['total']."</td><td>".$row8['total']."</td><td>".$row9['total']."</td><td>".$row10['total']."</td><tr>";         
           echo "</table>";
           echo "<br><br>";
           
          $sql= "SELECT count(*) as total FROM `vel` WHERE `expected` >89";
           $result = $link->query("$sql");
           $row1 = mysqli_fetch_assoc($result);    
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`expected` >79) and (`expected` <90)";
           $result = $link->query("$sql");
           $row2 = mysqli_fetch_assoc($result);       
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`expected` >69) and (`expected` <80)";
           $result = $link->query("$sql");
           $row3 = mysqli_fetch_assoc($result);    
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`expected` >59) and (`expected` <70)";
           $result = $link->query("$sql");
           $row4 = mysqli_fetch_assoc($result);   
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`expected` > 49) and (`expected` < 60) ";
           $result = $link->query("$sql");
           $row5 = mysqli_fetch_assoc($result);
        $sql= "SELECT count(*) as total FROM `vel` WHERE `expected` <>0 and `expected` is not null ";
           $result = $link->query("$sql");
           $row6 = mysqli_fetch_assoc($result);   
           
           echo "<b> STUDENT'S EXPECTED 12TH %:<b>&nbsp &nbsp &nbsp" ;
           
           echo "<br>";
           echo "<b> (no of entries):<b>".$row6['total'] ;
           echo "<br>";
           echo "<table border=\"1\" cellspacing=\"0\" >";
           echo "<tr><td><b>90% - 100%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>80% - 90%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>70% - 80%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>60% - 70%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>50% - 60%</b>&nbsp &nbsp &nbsp &nbsp  </td></tr>"; 
           echo  "<tr><td>".$row1['total']."</td><td>".$row2['total']."</td><td>".$row3['total']."</td><td>".$row4['total']."</td><td>".$row5['total']."</td><tr>";         
           echo "</table>";
           echo "<br><br>";
           
           $sql= "SELECT count(*) as total FROM `vel` WHERE `tenth` >89";
           $result = $link->query("$sql");
           $row1 = mysqli_fetch_assoc($result);    
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`tenth` >79) and (`tenth` <90)";
           $result = $link->query("$sql");
           $row2 = mysqli_fetch_assoc($result);       
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`tenth` >69) and (`tenth` <80)";
           $result = $link->query("$sql");
           $row3 = mysqli_fetch_assoc($result);    
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`tenth` >59) and (`tenth` <70)";
           $result = $link->query("$sql");
           $row4 = mysqli_fetch_assoc($result);   
         $sql= "SELECT count(*)as total FROM `vel` WHERE (`tenth` > 49) and (`tenth` < 60) ";
           $result = $link->query("$sql");
           $row5 = mysqli_fetch_assoc($result);
        $sql= "SELECT count(*) as total FROM `vel` WHERE `tenth` <>0 and `tenth` is not null";
           $result = $link->query("$sql");
           $row6 = mysqli_fetch_assoc($result);
           
           echo "<b> STUDENT'S 10TH %:<b>&nbsp &nbsp &nbsp" ;
           echo "<br>";
           echo "<b> (no of entries):<b>&nbsp".$row6['total'] ;
           echo "<br>";
           echo "<table border=\"1\" cellspacing=\"0\" >";
           echo "<tr><td><b>90% - 100%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>80% - 90%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>70% - 80%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>60% - 70%</b>&nbsp &nbsp &nbsp &nbsp  </td>";
           echo"<td><b>50% - 60%</b>&nbsp &nbsp &nbsp &nbsp  </td></tr>"; 
           echo  "<tr><td>".$row1['total']."</td><td>".$row2['total']."</td><td>".$row3['total']."</td><td>".$row4['total']."</td><td>".$row5['total']."</td><tr>";         
           echo "</table>";
           echo "<br><br>";
           
       mysqli_close($link);
	

?>
   <center>
         <button type="button" value="Print" onClick="window.print()" class="btn-outline-primary btn-lg" >Print</button> 
     </center>
</body>
</html>