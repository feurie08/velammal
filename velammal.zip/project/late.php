<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>B.E/B.TECH Lateral</title>
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        .bg{
    background-size: 100%;
    background-color: gray;
}
.form-container {
    width: 180%;
    position: absolute;
    top: 5vh;
    background: #fff;
    padding: 30px;
    border-radius:10px ;
    box-shadow: 0px 0px 15px 0px #000;
}
    </style>
</head>
<body>
<?php
 $link =new mysqli('localhost','root','root','velammal');
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        $user=$_GET['user'];
       //$user = $_SESSION["email"];
  if(isset($_POST['submit']))
{
         $key=uniqid();
         $a=$_POST['diploma'];
         $c=$_POST['mark'];
         $d=$_POST['pregno'];
         $e=$_POST['college'];
         $f=$_POST['dept'];
         $g=$_POST['doj'];
         $h=$_POST['med'];

         $sql = " UPDATE `vel` SET `ref`='$key',`diploma`='$a',`mark`='$c',`pregno`='$d',`college`='$e',`dept`='$f',`doj`='$g',`med`='$h' WHERE `email` ='$user' ";
         $_SESSION["uniq"] = $key;
       if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
       {           
                header("Location:middle.php");          
       }

       mysqli_close($link);
	
} ?>
    <section class="container-fluid bg">
        <section class="row justify-content-center">
            <section class="col col-sm-6 col-md-6 col-lg-4 col-xl-3">
              <div class="row justify-content-center align-items-center h-100">
                  <form class="form-container" action=<?php echo "late.php?user=".$user; ?> method="post" enctype="multipart/form-data">
                  <div class="form-group">
                    <center><h4>B.E/B.TECH LATERAL</h4></center>
                  </div>
                  <div class="form-group">Qualifying Exam Type</div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio1" name="diploma" value="Diploma" class="custom-control-input" >
                        <label class="custom-control-label" for="customRadio1">Diploma</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio2" name="diploma" value="B.Sc" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio2">B.Sc</label>
                      </div><br>
                      <span id="nameloc"></span>
                <div class="form-group">
                    <label for="exampleInputName">12th Mark (In % If Applicable)</label>
                    <input type="number" name="mark" class="form-control" id="exampleInputName1" placeholder="12th Mark (In % If Applicable)" onmouseout="marktw()"  minlength="2"  maxlength="3">
                    <span id="nameloc12"></span>
                </div>
                <div class="form-group">
                    <label for="exampleInputName">Registration Number (Diploma)</label>
                    <input type="number" name="pregno" class="form-control" id="exampleInputName2" onmouseout="rnum()" placeholder="Registration Number (Diploma)"  minlength="8"  maxlength="15" >
                    <span id="namelocreg"></span>
                </div>
                <div class="form-group">
                    <label for="exampleInputName">College</label>
                    <input type="text" name="college" class="form-control" id="exampleInputName4" onmouseout="dcol()" placeholder="College">
                    <span id="namelocdcol"></span>
                </div>
                <div class="form-group">
                    <label for="exampleInputName">Department in Diploma</label>
                    <input type="text" name="dept" class="form-control" id="exampleInputName3"  onmouseout="dname()" placeholder="Department in Diploma">
                    <span id="namelocdname"></span>
                </div>
                <div class="form-group">

                    <label for="exampleInputName">Date of Joining (Diploma)</label>
                    <input type="date" name="doj" class="form-control" id="exampleInputName5">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect2">Medium Of Instruction</label>
                    <select class="form-control" id="exampleFormControlSelect2" name="med" onmouseout="dmed()">
                        <option value="none" style="color: black">Medium of Instruction</option>
                        <option value="english" style="color: black">English</option>
                        <option value="tamil" style="color: black">Tamil</option>
                        <option value="telugu" style="color: black">Telegu</option>
                        <option value="other" style="color: black">Other</option>
                    </select>
                    <span id="namelocdmed"></span>
                </div>
                <center><button type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit"  id="submit">Submit</button></center>
                </form>
               </div>
            </section>
        </section>
    </section>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>