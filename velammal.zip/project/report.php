<!DOCTYPE html>
<html lang="en">
<head>
    <title>Report</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.jqueryui.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
   
    <body>
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.jqueryui.min.js"></script>
        <script>
                $(document).ready(function() {
                    $('#example').DataTable();
                } );
        </script>
    <table id="example" class="display">
        <thead>
            <tr>
                <th>Reference Number</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email Address</th>
                <th>Contact Number</th>
                <th>Alternate Number</th>
                <th>First Preference</th>
                <th>Second Preference</th>
                <th>From Velammal Group</th>
            </tr>
        </thead>
        <?php
        
$link = new mysqli('localhost','root','root','velammal');
if(!$link)
{
   die('could not connect: ' . $link->connect_error());
}

// $user =  $_SESSION["email"] ;
$sql = "SELECT `ref`,`fname`,`lname`,`email`,`num`,`anum`,`fpre`,`spre`,`vel` FROM `vel`";
$retval = mysqli_query( $link, $sql );
if(! $retval ) {
die('Could not get data: ' . connect_error());
}

while($row = mysqli_fetch_array($retval)) {
//mysqli_close($link);
        ?>
        
        <tbody>
            <tr>
            <td><?php echo $row['ref'] ?></td>
            <td><?php echo $row['fname'] ?></td>
            <td><?php echo $row['lname'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><?php echo $row['num'] ?></td>
            <td><?php echo $row['anum'] ?></td>
            <td><?php echo $row['fpre'] ?></td>
            <td><?php echo $row['spre'] ?></td>
            <td><?php echo $row['vel'] ?></td>
            </tr>
            </tbody>
            <?php            
            }
            //mysqli_close($link);
?>
            <tfoot>
                <th>Reference Number</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email Address</th>
                <th>Contact Number</th>
                <th>Alternate Number</th>
                <th>First Preference</th>
                <th>Second Preference</th>
                <th>From Velammal Group</th>
            </tfoot>
    </table><br><br>
    </body>
    <center>
        <button onclick="location.href = 'finalreport.php';" id="button1" class="btn btn-outline-success btn-lg" >Report</button>&nbsp;&nbsp;
        <button onclick="location.href = 'excel.php';" id="button1" class="btn btn-outline-success btn-lg" >Excel</button>
    </center>
    </html>
